<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

This project is a modern Python Flask web app for converting links (YouTube, etc) to MP4/MP3 and file-to-file conversion, with a modern index page UI (Bootstrap 5), and using Gemini API (Google AI) for extra features. The app should be easy to run locally.
