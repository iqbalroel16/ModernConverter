import os
import io
import tempfile
from flask import Flask, render_template, request, send_file, redirect, url_for, flash, session, make_response
from werkzeug.utils import secure_filename
import yt_dlp
import ffmpeg
import requests
from dotenv import load_dotenv
from mimetypes import guess_type
from functools import wraps
# Tambahan untuk dokumen
from pdf2docx import Converter as PDF2DocxConverter
from docx2pdf import convert as docx2pdf_convert
from PIL import Image
import uuid

load_dotenv()

app = Flask(__name__, static_url_path='/public', static_folder='public')
app.secret_key = os.urandom(24)

GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')
GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent'
USAGE_LOG = 'usage.log'

ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'admin123'

# In-memory cache untuk file hasil konversi (RAM, bukan session/cookie)
file_cache = {}

# Decorator for admin login required
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('admin_logged_in'):
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/', methods=['GET', 'POST'])
def index():
    mode = request.form.get('mode', 'link')
    if request.method == 'POST':
        mode = request.form.get('mode')
        link = request.form.get('link')
        file = request.files.get('file')
        output_format = request.form.get('output_format')
        input_format = request.form.get('input_format')
        doc_format = request.form.get('doc_format')
        quality = request.form.get('quality')
        gemini_feature = request.form.get('gemini_feature')
        site = request.form.get('site')
        result = None
        output_bytes = None
        output_filename = None
        # Fallback: ambil ekstensi file jika input_format/output_format kosong
        if file and (not input_format or not output_format):
            filename = file.filename
            ext = filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''
            if not input_format:
                input_format = ext
            if not output_format:
                output_format = ext
        # Link recognition logic
        if mode == 'link' and link:
            output_bytes, output_filename = download_from_link_memory(link, output_format, quality)
        elif mode == 'file' and file:
            output_bytes, output_filename = convert_file_memory(file, input_format, output_format)
        elif mode == 'document' and file:
            output_bytes, output_filename = convert_document_memory(file, input_format, output_format)
        if output_bytes:
            if gemini_feature:
                result = gemini_analyze(output_filename, gemini_feature)
            # Simpan file ke cache RAM dengan ID unik
            file_id = str(uuid.uuid4())
            file_cache[file_id] = (output_bytes.getvalue(), output_filename)
            return render_template('index.html', download_url=url_for('download_file_mem', file_id=file_id), result=result, mode=mode)
        else:
            flash('Please provide a valid input.')
    return render_template('index.html', mode=mode)

def download_from_link_memory(link, output_format, quality):
    import re
    import unicodedata
    def safe_filename(s):
        s = unicodedata.normalize('NFKD', s)
        s = re.sub(r'[\\/:*?"<>|]', '', s)
        s = re.sub(r'[\uD800-\uDBFF][\uDC00-\uDFFF]', '', s)
        s = s.replace('？', '').replace('#', '').replace(' ', '_')
        s = ''.join(c for c in s if c.isprintable())
        return s
    with tempfile.TemporaryDirectory() as tmpdir:
        if output_format == 'mp3':
            ydl_opts = {
                'outtmpl': f'{tmpdir}/%(title)s.%(ext)s',
                'format': 'bestaudio/best',
                'postprocessors': [
                    {
                        'key': 'FFmpegExtractAudio',
                        'preferredcodec': 'mp3',
                    }
                ],
            }
        elif output_format == 'mp4':
            if quality and quality.isdigit():
                ydl_format = f'bestvideo[height<={quality}]+bestaudio/best/best[height<={quality}]'
            else:
                ydl_format = 'bestvideo+bestaudio/best'
            ydl_opts = {
                'outtmpl': f'{tmpdir}/%(title)s.%(ext)s',
                'format': ydl_format,
                'merge_output_format': 'mp4',
            }
        else:
            ydl_opts = {
                'outtmpl': f'{tmpdir}/%(title)s.%(ext)s',
                'format': 'bestvideo+bestaudio/best',
            }
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(link, download=True)
            # Cari file terbesar di tmpdir (biasanya hasil download)
            files = [os.path.join(tmpdir, f) for f in os.listdir(tmpdir)]
            if not files:
                raise FileNotFoundError('No file found in temporary directory after download')
            largest_file = max(files, key=os.path.getsize)
            output_filename = os.path.basename(largest_file)
            with open(largest_file, 'rb') as f:
                file_content = f.read()
            output_bytes = io.BytesIO(file_content)
            output_bytes.seek(0)
            return output_bytes, output_filename

def convert_file_memory(file, input_format, output_format):
    input_bytes = file.read()
    if not input_bytes:
        raise Exception('File yang diupload kosong atau gagal dibaca.')
    # Gunakan NamedTemporaryFile dengan delete=False agar bisa diakses oleh ffmpeg di Windows
    with tempfile.NamedTemporaryFile(suffix=f'.{input_format}', delete=False) as in_tmp, tempfile.NamedTemporaryFile(suffix=f'.{output_format}', delete=False) as out_tmp:
        in_tmp.write(input_bytes)
        in_tmp.flush()
        in_tmp_name = in_tmp.name
        out_tmp_name = out_tmp.name
    try:
        (
            ffmpeg
            .input(in_tmp_name)
            .output(out_tmp_name)
            .run(overwrite_output=True)
        )
        with open(out_tmp_name, 'rb') as f:
            output_bytes = io.BytesIO(f.read())
        output_bytes.seek(0)
        output_filename = file.filename.rsplit('.', 1)[0] + f'.{output_format}'
    except ffmpeg.Error as e:
        err_msg = None
        if hasattr(e, 'stderr') and e.stderr:
            try:
                err_msg = e.stderr.decode()
            except Exception:
                err_msg = str(e)
        if not err_msg:
            err_msg = 'Gagal konversi file. Format tidak didukung atau file rusak.'
        raise Exception(err_msg)
    finally:
        try:
            os.remove(in_tmp_name)
        except Exception:
            pass
        try:
            os.remove(out_tmp_name)
        except Exception:
            pass
    return output_bytes, output_filename

def convert_document_memory(file, input_format, output_format):
    # Konversi dokumen di memori menggunakan tempfile, hasil langsung ke BytesIO
    input_bytes = file.read()
    with tempfile.NamedTemporaryFile(suffix=f'.{input_format}', delete=False) as in_tmp, tempfile.NamedTemporaryFile(suffix=f'.{output_format}', delete=False) as out_tmp:
        in_tmp.write(input_bytes)
        in_tmp.flush()
        in_tmp_name = in_tmp.name
        out_tmp_name = out_tmp.name
    # Tutup file agar tidak locked oleh proses lain (penting untuk Windows/COM)
    try:
        import subprocess
        subprocess.run(["unoconv", "-f", output_format, "-o", out_tmp_name, in_tmp_name], check=True)
    except Exception:
        # Fallback: PDF ke DOCX
        if input_format == 'pdf' and output_format == 'docx':
            cv = PDF2DocxConverter(in_tmp_name)
            cv.convert(out_tmp_name)
            cv.close()
        # DOCX ke PDF
        elif input_format == 'docx' and output_format == 'pdf':
            try:
                import pythoncom
                pythoncom.CoInitialize()
            except Exception:
                pass
            docx2pdf_convert(in_tmp_name, out_tmp_name)
        # JPG/PNG ke PDF
        elif input_format in ['jpg', 'jpeg', 'png'] and output_format == 'pdf':
            image = Image.open(in_tmp_name)
            image.save(out_tmp_name, 'PDF', resolution=100.0)
        # PDF ke JPG/PNG (halaman pertama)
        elif input_format == 'pdf' and output_format in ['jpg', 'png']:
            try:
                from pdf2image import convert_from_path
                images = convert_from_path(in_tmp_name, first_page=1, last_page=1)
                images[0].save(out_tmp_name, output_format.upper())
            except ImportError:
                raise Exception('pdf2image library is required for PDF to image conversion.')
        # Tambahan: fallback konversi file binary (copy as-is jika format sama)
        elif input_format == output_format:
            with open(out_tmp_name, 'wb') as f:
                f.write(input_bytes)
        else:
            # Fallback universal: copy as-is (rename extension)
            with open(out_tmp_name, 'wb') as f:
                f.write(input_bytes)
    # Baca hasil output
    with open(out_tmp_name, 'rb') as f:
        output_bytes = io.BytesIO(f.read())
    output_bytes.seek(0)
    output_filename = file.filename.rsplit('.', 1)[0] + f'.{output_format}'
    # Bersihkan file temp
    try:
        os.remove(in_tmp_name)
    except Exception:
        pass
    try:
        os.remove(out_tmp_name)
    except Exception:
        pass
    return output_bytes, output_filename

@app.route('/download_mem/<file_id>')
def download_file_mem(file_id):
    file_data = file_cache.pop(file_id, None)  # Hapus dari cache setelah diunduh
    if not file_data:
        flash('File tidak ditemukan atau sudah diunduh. Silakan ulangi proses convert.')
        return redirect(url_for('index'))
    output_bytes, output_filename = file_data
    return send_file(
        io.BytesIO(output_bytes),
        as_attachment=True,
        download_name=output_filename
    )

def gemini_analyze(filename, feature):
    # Example: send file info to Gemini API for summary/description
    headers = {'Content-Type': 'application/json'}
    data = {
        'contents': [{
            'parts': [{
                'text': f'Analyze this file for {feature}: {filename}'
            }]
        }]
    }
    params = {'key': GEMINI_API_KEY}
    response = requests.post(GEMINI_API_URL, headers=headers, params=params, json=data)
    if response.ok:
        return response.json().get('candidates', [{}])[0].get('content', {}).get('parts', [{}])[0].get('text', '')
    return 'No result from Gemini.'

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['admin_logged_in'] = True
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Invalid credentials!')
    return render_template('admin_login.html')

@app.route('/admin/logout')
def admin_logout():
    session.pop('admin_logged_in', None)
    return redirect(url_for('admin_login'))

@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    usage_count = 0
    if os.path.exists(USAGE_LOG):
        with open(USAGE_LOG, 'r') as f:
            usage_count = len(f.readlines())
    return render_template('admin_dashboard.html', usage_count=usage_count)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/privacy')
def privacy():
    return render_template('privacy.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/donasi')
def donasi():
    return render_template('donasi.html')

if __name__ == '__main__':
    app.run(debug=True)
